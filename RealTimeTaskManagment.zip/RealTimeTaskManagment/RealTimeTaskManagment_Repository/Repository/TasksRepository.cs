﻿using RealTimeTaskManagment_Models.Entities;
using RealTimeTaskManagment_Models;
using SharedModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RealTimeTaskManagment_Repository.Repository
{
    public class TasksRepository
    {

        public TaskManagmentSystemDBContext Context { get; }

        public TasksRepository(TaskManagmentSystemDBContext context)
        {
            Context = context;
        }

        public List<Tasks> GetTasks(List<long> ids)
        {
            try
            {
                return Context.Tasks.Where(x => ids.Contains(x.Id) && !x.IsDeleted).ToList();

            }
            catch (Exception ex)
            {

                throw;
            }
        }

        public Result<Tasks> GetTasksById(long id)
        {
            try
            {
                var task = Context.Tasks.FirstOrDefault(x => x.Id == id);


                return task != null
                    ? Result<Tasks>.Success(task)
                    : Result<Tasks>.Error("Task Not Found");
            }
            catch (Exception ex)
            {

                throw;
            }

        }



    }
}
