﻿using RealTimeTaskManagment_Models;
using RealTimeTaskManagment_Models.Entities;
using SharedModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RealTimeTaskManagment_Repository.Repository
{
    public class EmployeeRepository
    {
        public TaskManagmentSystemDBContext Context { get; }

        public EmployeeRepository(TaskManagmentSystemDBContext context)
        {
            Context = context;
        }

        public List<Employee> GetEmployees(List<long> ids)
        {
            try
            {
                return Context.Employee.Where(x => ids.Contains(x.Id) && !x.IsDeleted).ToList();

            }
            catch (Exception ex)
            {

                throw;
            }
        }

        public Result<Employee> GetEmployeeById(long id)
        {
            try
            {
                var employee = Context.Employee.FirstOrDefault(x => x.Id == id);

     
                return employee != null
                    ? Result<Employee>.Success(employee)
                    : Result<Employee>.Error("Employee Not Found");
            }
            catch (Exception ex)
            {

                throw;
            }
 
        }
    }
}
