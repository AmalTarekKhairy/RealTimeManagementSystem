﻿using RealTimeTaskManagment_Models;
using RealTimeTaskManagment_Repository.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RealTimeTaskManagment_Repository
{
    public interface IUnitOfWork
    {
        TaskManagmentSystemDBContext Context { get; }
        EmployeeRepository EmployeeRepository  { get; }
        TasksRepository TasksRepository { get; }

        void SaveChanges();


    }
}
