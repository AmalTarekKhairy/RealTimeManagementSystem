﻿using RealTimeTaskManagment_Models;
using RealTimeTaskManagment_Repository.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RealTimeTaskManagment_Repository
{
    public class UnitOfWork : IUnitOfWork
    {
        public TaskManagmentSystemDBContext Context { get; }

        public EmployeeRepository EmployeeRepository { get; }

        public TasksRepository TasksRepository { get; }

        public UnitOfWork(TaskManagmentSystemDBContext context, EmployeeRepository employeeRepository, TasksRepository tasksRepository)
        {
            Context = context;
            EmployeeRepository = employeeRepository;
            TasksRepository = tasksRepository;
        }


        public void SaveChanges()
        {
            Context.SaveChanges();
        }
    }
}
