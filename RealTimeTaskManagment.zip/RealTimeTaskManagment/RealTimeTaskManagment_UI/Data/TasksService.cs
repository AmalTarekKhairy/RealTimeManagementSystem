using static System.Net.WebRequestMethods;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Net.Http.Json;
using RealTimeTaskManagment_API;

namespace RealTimeTaskManagment_UI.Data
{
    public class TasksService
    {
        public HttpClient Http;
        public IConfiguration Configuration;

        public TasksService(HttpClient http, IConfiguration configuration)
        {
            Http = http;
            Configuration = configuration;
        }

        public async Task<List< Tasks>> GetTasksAsync()
        {
            try
            {
                //Calling End point Here
                string URL = "http://localhost:5000/controller/GetTasks";
                long id = 0;
           
                var response = await Http.PostAsJsonAsync(URL, id);
                var parsedResponse = await response.Content.ReadFromJsonAsync<List<TasksDTO>>();
                return new List<Tasks>();
            }
            catch (Exception ex)
            {

                throw;
            }
        }
    }
}