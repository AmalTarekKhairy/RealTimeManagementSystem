namespace RealTimeTaskManagment_UI.Data
{
    public class Tasks
    {
        public DateTime CreationDate { get; set; }
        public DateOnly DueDate { get; set; }
        public long Id { get; set; }
        public int TemperatureC { get; set; }

        public string Title { get; set; }

        public string? Description { get; set; }






    }
}