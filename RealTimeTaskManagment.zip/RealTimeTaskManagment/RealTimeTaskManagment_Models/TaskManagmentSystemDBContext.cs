﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using RealTimeTaskManagment_Models.Entities;

namespace RealTimeTaskManagment_Models
{
    public class TaskManagmentSystemDBContext : IdentityDbContext<ApplicationUser.ApplicationUser,IdentityRole<long>,long>
    {

        protected static readonly string DefaultSchemaName = "dbo";
        private readonly IConfiguration configuration;

        public TaskManagmentSystemDBContext(DbContextOptions<TaskManagmentSystemDBContext> options, IConfiguration _configuration) :base(options)
        {
            configuration = _configuration;
        }


        #region Entities
        public virtual DbSet<Employee> Employee { get; set; }
        public virtual DbSet<Tasks> Tasks { get; set; }
 
        #endregion


        protected override void OnModelCreating(ModelBuilder builder)
        {
            //Set default Schema
            builder.HasDefaultSchema(DefaultSchemaName);
            base.OnModelCreating(builder);

        }



        //protected override void OnConfiguring(DbContextOptionsBuilder optionBuilder)
        //{
            //var configuration = new ConfigurationBuilder()
            //                        //.SetBasePath(Directory.GetCurrentDirectory().Replace("Test\\LS.Controller.Test", "Services\\LS.Services.API"))
            //                        .AddJsonFile("appsettings.json")
            //                        .Build();

            //var connectionString = configuration.GetConnectionString("RealTimeTaskManagment");
            
            //optionBuilder.UseSqlServer(connectionString);
        //}


    }
}
