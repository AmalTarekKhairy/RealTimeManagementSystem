namespace RealTimeTaskManagment_API
{
    public class TasksDTO
    {

        public TasksDTO()
        {
            
        }

        public TasksDTO(long id, string title, string description, DateTime creationDate, DateTime dueDate, bool isDeleted)
        {
            Id = id;
            Title = title;
            Description = description;
            CreationDate = creationDate;
            DueDate = dueDate;
            IsDeleted = isDeleted;
        }

        public long Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public DateTime CreationDate { get; set; }
        public DateTime DueDate { get; set; }
        public bool IsDeleted { get; set; }
    }
}