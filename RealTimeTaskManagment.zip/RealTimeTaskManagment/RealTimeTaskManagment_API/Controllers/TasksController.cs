using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RealTimeTaskManagment_BussinessLayer.BusinessLayer;
using SharedModels;

namespace RealTimeTaskManagment_API.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [Authorize]
    public class TasksController : ControllerBase
    {
     

        private readonly ILogger<TasksController> _logger;

        private readonly ITasksBL _tasksBL;

        public TasksController(ILogger<TasksController> logger, ITasksBL tasksBL)
        {
            _logger = logger;
            _tasksBL = tasksBL;
        }

        [HttpGet(Name = "GetTasks")]
        public Result< List<RealTimeTaskManagment_API.TasksDTO>> GetTasks(long id)
        {
            try
            {
                var tasks = _tasksBL.GetTasks(id);

                var tasksDTO = tasks.HasError ? Result<List<RealTimeTaskManagment_API.TasksDTO>>.Error("No Tasks Found")
                                              : Result<List<RealTimeTaskManagment_API.TasksDTO>>.Success(tasks.Value.Select(q=> new TasksDTO(q.Id, q.Title, q.Description, q.CreationDate, q.DueDate, q.IsDeleted)).ToList());

                return tasksDTO;
            }
            catch (Exception ex)
            {

                throw;
            }
        }
    }
}