﻿namespace SharedModels
{
 
    public class Result<T>
    {
        #region Properties

        public T Value { get; private init; }
        public bool HasError { get; private init; }
        public string Message{ get; private init; }

        #endregion

        #region Methods

        public static Result<T> Success(T value)
        {
            try
            {
                return new Result<T> { Value = value, HasError = false, Message ="Success" };
            }
            catch (Exception e)
            {
                throw;
            }
        }



        public static Result<T> Error(string message)
        {
            try
            {
                return new Result<T>
                {
                    HasError = true,
                    Message = message

                };
            }
            catch (Exception e)
            {
                throw;
            }
        }



        #endregion
    }

}