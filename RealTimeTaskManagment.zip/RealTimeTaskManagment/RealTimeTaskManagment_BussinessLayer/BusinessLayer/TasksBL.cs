﻿using RealTimeTaskManagment_Models.Entities;
using RealTimeTaskManagment_Repository;
using SharedModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RealTimeTaskManagment_BussinessLayer.BusinessLayer
{
    public class TasksBL : ITasksBL
    {

        public UnitOfWork UnitOfWork { get; set; }

        public TasksBL(UnitOfWork unitOfWork)
        {
            UnitOfWork = unitOfWork;
        }


        public Result<List<Tasks>> GetTasks(long id)
        {
            try
            {
                var tasks = UnitOfWork.EmployeeRepository.GetEmployeeById(id).HasError ? Result<List<Tasks>>.Error("No Tasks Found")
                    : Result<List<Tasks>>.Success(UnitOfWork.EmployeeRepository.GetEmployeeById(id).Value.Tasks.ToList());

                return tasks;
            }
            catch (Exception ex)
            {

                throw;
            }
        }



    }
}
