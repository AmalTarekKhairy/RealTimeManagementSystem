﻿using RealTimeTaskManagment_Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RealTimeTaskManagment_BussinessLayer.BusinessLayer
{
    public class TasksBL
    {

        public UnitOfWork UnitOfWork { get; set; }

        public TasksBL(UnitOfWork unitOfWork)
        {
            UnitOfWork = unitOfWork;
        }




       



    }
}
