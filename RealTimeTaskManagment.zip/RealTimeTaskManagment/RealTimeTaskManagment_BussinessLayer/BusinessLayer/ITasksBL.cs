﻿using RealTimeTaskManagment_Models.Entities;
using RealTimeTaskManagment_Repository;
using SharedModels;

namespace RealTimeTaskManagment_BussinessLayer.BusinessLayer
{
    public interface ITasksBL
    {
        UnitOfWork UnitOfWork { get; set; }

        Result<List<Tasks>> GetTasks(long id);
    }
}